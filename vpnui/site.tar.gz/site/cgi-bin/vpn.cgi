#!/var/tmp/vpnui/bin/busybox-mips ash
BB=/var/tmp/vpnui/bin/busybox-mips
ROOT=/var/tmp/vpnui/www
XRAY=/var/tmp/xray
BASE=/var/tmp/vpnui
STATE=$BASE/state
MODEFILE=$BASE/mode
START=$BASE/started_at
PID=$BASE/xray.pid
LOG=$BASE/xray.log
ACTION=status
ID=
MODE=tunnel

urldecode(){ v=$(echo "$1" | sed 's/+/ /g;s/%/\\x/g'); printf '%b' "$v"; }
for p in $(echo "$QUERY_STRING" | tr '&' ' '); do
  k=${p%%=*}; v=${p#*=}; v=$(urldecode "$v")
  [ "$k" = "action" ] && ACTION=$v
  [ "$k" = "id" ] && ID=$v
  [ "$k" = "mode" ] && MODE=$v
done
[ "$MODE" = "proxy" ] || MODE=tunnel

node_line(){ grep "^$1|" "$ROOT/nodes.txt" | head -1; }
node_host(){ node_line "$1" | cut -d '|' -f 3; }
node_ping(){ node_line "$1" | cut -d '|' -f 4; }
node_ips(){ node_line "$1" | cut -d '|' -f 5 | tr ',' ' '; }
json_escape(){ echo "$1" | sed 's/\\/\\\\/g;s/"/\\"/g;s/	/ /g'; }
uptime_now(){ cut -d ' ' -f 1 /proc/uptime | cut -d '.' -f 1; }
is_running(){ ps | grep '[x]ray run' >/dev/null 2>&1; }
nat_enabled(){ iptables -t nat -S PREROUTING 2>/dev/null | grep -q 'XRAY'; }
cleanup_nat(){
  while iptables -t nat -D PREROUTING -i br2 -s 192.168.0.0/24 -p tcp -j XRAY 2>/dev/null; do :; done
}
stop_vpn(){
  cleanup_nat
  killall xray 2>/dev/null
  rm -f "$PID" "$START"
}
clear_logs(){
  : > "$LOG"
  : > "$BASE/xray.access.log"
  : > "$BASE/traffic.tmp"
}
apply_nat(){
  id="$1"
  iptables -t nat -N XRAY 2>/dev/null
  iptables -t nat -F XRAY
  for src in $(grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}$' "$BASE/rules.txt" 2>/dev/null); do
    iptables -t nat -A XRAY -s "$src" -j RETURN
  done
  for cidr in 0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4; do
    iptables -t nat -A XRAY -d $cidr -j RETURN
  done
  for ip in $(node_ips "$id"); do [ -n "$ip" ] && iptables -t nat -A XRAY -d "$ip/32" -j RETURN; done
  iptables -t nat -A XRAY -p tcp -j REDIRECT --to-ports 12345
  iptables -t nat -I PREROUTING 1 -i br2 -s 192.168.0.0/24 -p tcp -j XRAY
}
open_ports(){
  for port in 1080 1081 12345; do
    iptables -C INPUT -i br2 -p tcp --dport "$port" -j ACCEPT 2>/dev/null || iptables -I INPUT 1 -i br2 -p tcp --dport "$port" -j ACCEPT
  done
}
start_vpn(){
  id="$1"; mode="$2"
  [ -f "$ROOT/configs/$id.json" ] || return 2
  [ -x "$XRAY" ] || return 3
  stop_vpn
  cp "$ROOT/configs/$id.json" "$BASE/active.json"
  : > "$LOG"; : > "$BASE/xray.access.log"
  ($XRAY run -config "$BASE/active.json" >> "$LOG" 2>&1 & echo $! > "$PID")
  sleep 1
  is_running || return 4
  cleanup_nat
  [ "$mode" = "tunnel" ] && apply_nat "$id"
  open_ports
  echo "$id" > "$STATE"; echo "$mode" > "$MODEFILE"; uptime_now > "$START"
  return 0
}
status_json(){
  id=""; [ -f "$STATE" ] && id=$(cat "$STATE")
  mode="tunnel"; [ -f "$MODEFILE" ] && mode=$(cat "$MODEFILE")
  started=""; elapsed=0
  if [ -f "$START" ]; then
    started=$(cat "$START")
    now=$(uptime_now)
    elapsed=$((now-started))
    [ "$elapsed" -lt 0 ] && elapsed=0
  fi
  host=$(json_escape "$(node_host "$id")")
  ping=$(node_ping "$id")
  running=false; is_running && running=true
  nat=false; nat_enabled && nat=true
  enabled=false; [ "$running" = true ] && enabled=true
  echo "{\"enabled\":$enabled,\"running\":$running,\"nat\":$nat,\"id\":\"$id\",\"mode\":\"$mode\",\"host\":\"$host\",\"ping\":\"$ping\",\"started\":\"$started\",\"elapsed\":$elapsed,\"message\":\"ok\"}"
}

printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
case "$ACTION" in
  connect)
    start_vpn "$ID" "$MODE"; rc=$?
    if [ "$rc" = 0 ]; then status_json; else echo "{\"enabled\":false,\"id\":\"$ID\",\"mode\":\"$MODE\",\"message\":\"connect failed rc=$rc\"}"; fi
    ;;
  disconnect)
    stop_vpn
    echo '{"enabled":false,"running":false,"nat":false,"id":"","mode":"tunnel","host":"","ping":"","started":"","elapsed":0,"message":"disabled"}'
    ;;
  restart)
    id=""; [ -f "$STATE" ] && id=$(cat "$STATE")
    mode="tunnel"; [ -f "$MODEFILE" ] && mode=$(cat "$MODEFILE")
    [ -n "$ID" ] && id="$ID"
    start_vpn "$id" "$mode"; rc=$?
    if [ "$rc" = 0 ]; then status_json; else echo "{\"enabled\":false,\"id\":\"$id\",\"mode\":\"$mode\",\"message\":\"restart failed rc=$rc\"}"; fi
    ;;
  clearlogs)
    clear_logs
    echo '{"ok":true,"message":"logs cleared"}'
    ;;
  status|*)
    status_json
    ;;
esac
