#!/var/tmp/vpnui/bin/busybox-mips ash
BASE=/var/tmp/vpnui
BB=/var/tmp/vpnui/bin/busybox-mips
URLFILE=$BASE/subscription.url
RAW=$BASE/subscription.raw
ACTION=save
URL=
urldecode(){ v=$(echo "$1" | sed 's/+/ /g;s/%/\\x/g'); printf '%b' "$v"; }
json_escape(){ echo "$1" | sed 's/\\/\\\\/g;s/"/\\"/g'; }
for p in $(echo "$QUERY_STRING" | tr '&' ' '); do
  k=${p%%=*}; v=${p#*=}; v=$(urldecode "$v")
  [ "$k" = "action" ] && ACTION=$v
  [ "$k" = "url" ] && URL=$v
done
printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
mkdir -p "$BASE"
if [ "$ACTION" = "save" ]; then
  echo "$URL" > "$URLFILE"
  msg="saved"
  if [ -x "$BB" ]; then
    "$BB" wget -O "$RAW" "$URL" >/dev/null 2>&1 && msg="saved and downloaded"
  fi
  count=0
  [ -f "$RAW" ] && count=$(grep -o 'vless://' "$RAW" 2>/dev/null | wc -l)
  m=$(json_escape "$msg")
  echo "{\"ok\":true,\"message\":\"$m\",\"vless\":$count}"
else
  u=""; [ -f "$URLFILE" ] && u=$(json_escape "$(cat "$URLFILE")")
  echo "{\"ok\":true,\"url\":\"$u\"}"
fi
