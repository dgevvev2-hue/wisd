#!/var/tmp/vpnui/bin/busybox-mips ash
BB=/var/tmp/vpnui/bin/busybox-mips
BASE=/var/tmp/vpnui
json_escape(){ echo "$1" | sed 's/\\/\\\\/g;s/"/\\"/g;s/	/ /g'; }
uptime_s(){ cut -d ' ' -f 1 /proc/uptime | cut -d '.' -f 1; }
mem_total=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
mem_free=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
[ -z "$mem_free" ] && mem_free=$(awk '/MemFree/ {print $2}' /proc/meminfo)
load=$(cat /proc/loadavg | cut -d ' ' -f 1-3)
lxcline=$(df -k /var/LxC 2>/dev/null | awk 'NR==2 {print $2 "|" $3 "|" $4 "|" $5}')
tmp_line=$(df -k /var/tmp 2>/dev/null | awk 'NR==2 {print $2 "|" $3 "|" $4 "|" $5}')
vpn=false; ps | grep '[x]ray run' >/dev/null 2>&1 && vpn=true
httpd=false; ps | grep '[h]ttpd' >/dev/null 2>&1 && httpd=true
ftp=false; ps | grep '[t]cpsvd' >/dev/null 2>&1 && ftp=true
sftp=false; [ -x "$BASE/bin/sftp-server" ] && [ -f /etc/passwd ] && sftp=true
temp=""
for f in /sys/class/thermal/thermal_zone*/temp; do
  [ -f "$f" ] && temp=$(cat "$f" 2>/dev/null | head -1)
done
printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
echo "{"
echo "\"uptime\":$(uptime_s),\"load\":\"$(json_escape "$load")\",\"memTotal\":${mem_total:-0},\"memFree\":${mem_free:-0},\"temp\":\"$(json_escape "$temp")\","
echo "\"storage\":{\"lxc\":\"$(json_escape "$lxcline")\",\"tmp\":\"$(json_escape "$tmp_line")\"},"
echo "\"services\":{\"vpn\":$vpn,\"http\":$httpd,\"ftp\":$ftp,\"sftpPort\":$sftp},"
echo "\"devices\":["
first=1
awk 'NR>1 && $4!="00:00:00:00:00:00" {print $1 "|" $4 "|" $6}' /proc/net/arp | while IFS='|' read ip mac dev; do
  [ -z "$ip" ] && continue
  [ "$first" = 0 ] && echo ","
  first=0
  vendor="Device"
  case "$mac" in
    94:bb:43*|94:e0:d6*) vendor="PC/Laptop" ;;
    68:4e:05*|3c:0b:4f*|94:87:e0*|ae:74:6d*|1a:98:bc*) vendor="Phone/Client" ;;
  esac
  echo -n "{\"ip\":\"$ip\",\"mac\":\"$mac\",\"iface\":\"$dev\",\"type\":\"$vendor\"}"
done
echo ""
echo "]}"
