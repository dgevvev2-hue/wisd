#!/var/tmp/vpnui/bin/busybox-mips ash
BB=/var/tmp/vpnui/bin/busybox-mips
BASE=/var/tmp/vpnui
LOG=$BASE/xray.log
ACCESS=$BASE/xray.access.log
printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
if [ ! -f "$LOG" ] && [ ! -f "$ACCESS" ]; then echo '[]'; exit 0; fi
TMP=$BASE/traffic.tmp
: > "$TMP"
if [ -f "$LOG" ]; then
  $BB tail -350 "$LOG" | $BB awk '
  function idof(line){ if (match(line, /\[[0-9]+\]/)) return substr(line, RSTART+1, RLENGTH-2); return ""; }
  function clean(v){ sub(/^tcp:/,"",v); sub(/^udp:/,"",v); sub(/:[0-9]+$/,"",v); gsub(/[\r\n]/,"",v); return v; }
  {
    id=idof($0); if (id == "") next;
    if ($0 ~ /received request for/) { src=$NF; sub(/:[0-9]+$/,"",src); s[id]=src; next; }
    if ($0 ~ /sniffed domain:/) { d=$NF; d=clean(d); if (d !~ /^[0-9.]+$/ && d != "") print $2 "|" (s[id] ? s[id] : "router") "|" d; next; }
    if ($0 ~ /tunneling request to tcp:/) { d=$0; sub(/^.*tunneling request to tcp:/,"",d); sub(/ via .*$/,"",d); d=clean(d); if (d !~ /^[0-9.]+$/ && d != "") print $2 "|" (s[id] ? s[id] : "router") "|" d; next; }
  }' >> "$TMP"
fi
if [ -f "$ACCESS" ]; then
  $BB tail -120 "$ACCESS" | $BB awk '
  function clean(v){ sub(/^\/\//,"",v); sub(/^tcp:/,"",v); sub(/^udp:/,"",v); sub(/:[0-9]+$/,"",v); return v; }
  / accepted / {
    tm=$2; src=$3; dst=$5; sub(/:[0-9]+$/,"",src); dst=clean(dst);
    if (dst !~ /^[0-9.]+$/ && dst != "") print tm "|" src "|" dst;
  }' >> "$TMP"
fi
echo '['
$BB tail -80 "$TMP" | $BB awk -F'|' '
BEGIN{first=1}
NF>=3 && !seen[$2 "|" $3]++ {
  gsub(/"/,"",$1); gsub(/"/,"",$2); gsub(/"/,"",$3);
  if(first==0) printf ",\n"; first=0;
  printf "{\"time\":\"%s\",\"src\":\"%s\",\"dst\":\"%s\"}",$1,$2,$3;
}
END{print "\n]"}'
