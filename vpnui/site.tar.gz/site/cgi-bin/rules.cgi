#!/var/tmp/vpnui/bin/busybox-mips ash
BASE=/var/tmp/vpnui
RULES=$BASE/rules.txt
ACTION=list
VALUE=
urldecode(){ v=$(echo "$1" | sed 's/+/ /g;s/%/\\x/g'); printf '%b' "$v"; }
for p in $(echo "$QUERY_STRING" | tr '&' ' '); do
  k=${p%%=*}; v=${p#*=}; v=$(urldecode "$v")
  [ "$k" = "action" ] && ACTION=$v
  [ "$k" = "value" ] && VALUE=$v
done
safe_value(){ echo "$1" | tr -cd 'A-Za-z0-9*._:-'; }
dedupe_rules(){
  awk 'NF && !seen[$0]++ { print $0 }' "$RULES" > "$RULES.tmp" 2>/dev/null
  mv "$RULES.tmp" "$RULES"
}
json_list(){
  echo -n '{"rules":['
  first=1
  if [ -f "$RULES" ]; then
    while read r; do
      [ -z "$r" ] && continue
      [ "$first" = 0 ] && echo -n ','
      first=0
      r=$(echo "$r" | sed 's/\\/\\\\/g;s/"/\\"/g')
      echo -n "\"$r\""
    done < "$RULES"
  fi
  echo ']}'
}
mkdir -p "$BASE"
touch "$RULES"
case "$ACTION" in
  add)
    v=$(safe_value "$VALUE")
    if [ -n "$v" ] && ! grep -qx "$v" "$RULES" 2>/dev/null; then echo "$v" >> "$RULES"; fi
    ;;
  delete)
    v=$(safe_value "$VALUE")
    grep -vx "$v" "$RULES" > "$RULES.tmp" 2>/dev/null
    mv "$RULES.tmp" "$RULES"
    ;;
esac
dedupe_rules
printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
json_list
