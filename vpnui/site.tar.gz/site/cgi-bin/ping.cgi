#!/var/tmp/vpnui/bin/busybox-mips ash
BB=/var/tmp/vpnui/bin/busybox-mips
ROOT=/var/tmp/vpnui/www
OUT=/var/tmp/vpnui/pings.json
HOST=
urldecode(){ v=$(echo "$1" | sed 's/+/ /g;s/%/\\x/g'); printf '%b' "$v"; }
for p in $(echo "$QUERY_STRING" | tr '&' ' '); do
  k=${p%%=*}; v=${p#*=}; v=$(urldecode "$v")
  [ "$k" = "host" ] && HOST=$v
done
printf 'Content-Type: application/json; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'
if [ -n "$HOST" ]; then
  safe=$(echo "$HOST" | tr -cd 'A-Za-z0-9._:-')
  line=$(ping -c 1 "$safe" 2>/dev/null | grep 'time=' | head -1)
  avg=$(echo "$line" | sed -n 's/.*time=\([0-9.]*\).*/\1/p')
  [ -z "$avg" ] && avg=null
  echo "{\"host\":\"$safe\",\"ping\":$avg}"
  exit 0
fi
echo -n '{"pings":{' > "$OUT"
first=1
while IFS='|' read id name host old ips; do
  [ -z "$id" ] && continue
  line=$(ping -c 1 "$host" 2>/dev/null | grep 'time=' | head -1)
  ms=$(echo "$line" | sed -n 's/.*time=\([0-9.]*\).*/\1/p')
  [ -z "$ms" ] && continue
  [ "$first" = 0 ] && echo -n ',' >> "$OUT"
  first=0
  echo -n "\"$id\":$ms" >> "$OUT"
done < "$ROOT/nodes.txt"
echo '}}' >> "$OUT"
cat "$OUT"
